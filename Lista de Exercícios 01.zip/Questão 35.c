#include <stdio.h>
#include <stdlib.h>

int main()
{

 double a, b, c, d;



    scanf("%lf %lf", &a, &b);
    c = sqrt((a*a)+(b*b));
    printf("%lf \n", c);



    return 0;

}
