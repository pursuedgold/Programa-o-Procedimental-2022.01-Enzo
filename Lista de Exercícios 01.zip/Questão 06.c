#include <stdio.h>
#include <stdlib.h>

int main()
{

 double a, f=0;



    scanf("%lf", &a);
    f= a*(9.0/5.0)+32.0;
    printf("%lf \n", f);



    return 0;

}
