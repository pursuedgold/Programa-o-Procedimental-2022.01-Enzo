#include <stdio.h>
#include <stdlib.h>

int main()
{

 int a, b, c, resultado=0;


    printf("Digite 3 valores: \n");
    scanf("%d %d %d", &a, &b, &c);
    resultado= a+b+c;
    printf("A soma destes numeros e: %d \n", resultado);
















    return 0;

}
