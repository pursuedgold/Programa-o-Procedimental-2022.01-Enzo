#include <stdio.h>
#include <stdlib.h>

int main()
{

 double a, b=0;



    scanf("%lf", &a);
    b = a*0.000247;
    printf("%lf \n", b);



    return 0;

}
