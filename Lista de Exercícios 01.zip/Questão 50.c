#include <stdio.h>
#include <stdlib.h>

int main()
{


int idade, ano;

scanf("%d %d", &idade, &ano);

printf ("Nasceu no ano %d ", ano-idade);


return 0;

}
