#include <stdio.h>
#include <stdlib.h>

int main()
{

 double a, quadrado=0;



    scanf("%lf", &a);
    quadrado= a*a;
    printf("%lf \n", quadrado);





    return 0;

}
