#include <stdio.h>
#include <stdlib.h>

int main()
{


double a, b;

    scanf("%lf %lf", &a, &b);
    printf("%lf \n", 3.141592*b*b*a);








return 0;

}
