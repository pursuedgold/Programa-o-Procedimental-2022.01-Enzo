#include <stdio.h>
#include <stdlib.h>

int main()
{


double a, b;

    scanf("%lf", &a);
    printf("%lf \n", a*0.88);








return 0;

}
