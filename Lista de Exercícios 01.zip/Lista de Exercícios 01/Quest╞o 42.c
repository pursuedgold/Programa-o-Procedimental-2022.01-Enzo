#include <stdio.h>
#include <stdlib.h>

int main()
{


double a, b;




    scanf("%lf", &a);
    b = a*0.07;
    a = (a*1.05) - b;
    printf("%lf", a);








return 0;

}
