#include <stdio.h>
#include <stdlib.h>

int main()
{

 double a;

  scanf("%lf", &a);
    printf("%lf \n", a);














    return 0;

}
