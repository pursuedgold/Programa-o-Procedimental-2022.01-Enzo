#include <stdio.h>
#include <stdlib.h>

int main()
{


char a[3];

scanf("%s", &a);
int i = 2;
printf("Numero_lido: %s \nNumero_Formado: ", a);

printf("%c", a[i]);
i--;
printf("%c", a[i]);
i--;
printf("%c", a[i]);








return 0;

}
