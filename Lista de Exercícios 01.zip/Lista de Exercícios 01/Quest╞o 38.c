#include <stdio.h>
#include <stdlib.h>

int main()
{


double a, b;

    scanf("%lf", &a);
    printf("%lf \n", a*1.25);








return 0;

}
