#include <stdio.h>
#include <stdlib.h>

int main()
{


double a;




    scanf("%lf", &a);
    printf("%lf", (a*30)*0.92);








return 0;

}
