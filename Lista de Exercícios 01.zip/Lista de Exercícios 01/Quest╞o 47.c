#include <stdio.h>
#include <stdlib.h>

int main()
{


char a[4];

scanf("%s", &a);

printf("%c \n", a[0]);

printf("%c \n", a[1]);

printf("%c \n", a[2]);

printf("%c \n", a[3]);






return 0;

}
