#include <stdio.h>
#include <stdlib.h>

int main()
{


double a, b;




    scanf("%lf %lf", &a, &b);


    printf("Deverao ser subidos %.0lf Degraus", b/a);








return 0;

}
