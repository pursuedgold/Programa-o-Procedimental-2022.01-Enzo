#include <stdio.h>
#include <stdlib.h>

int main()
{

 double a, f;



    scanf("%lf", &f);
    a = 5.0*(f-32.0)/9.0;
    printf("%lf \n", a);



    return 0;

}
