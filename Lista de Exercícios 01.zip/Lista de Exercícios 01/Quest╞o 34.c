#include <stdio.h>
#include <stdlib.h>

int main()
{

 double a, b, c, d;



    scanf("%lf", &a);

    printf("%lf \n", (a*a)*3.141592);



    return 0;

}
