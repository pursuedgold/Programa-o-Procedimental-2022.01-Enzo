#include <stdio.h>
#include <stdlib.h>

int main()
{

 double a, b, c, d;



    scanf("%lf %lf %lf %lf", &a, &b, &c, &d);

    printf("%lf \n", (a+b+c+d)/4);



    return 0;

}
