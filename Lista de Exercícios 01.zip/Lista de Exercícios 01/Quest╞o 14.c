#include <stdio.h>
#include <stdlib.h>

int main()
{

 double a, b=0;



    scanf("%lf", &a);
    b = (a*3.141592)/180;
    printf("%lf \n", b);



    return 0;

}
