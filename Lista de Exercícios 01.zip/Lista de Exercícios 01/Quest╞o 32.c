#include <stdio.h>
#include <stdlib.h>

int main()
{

 int a, b, c, d;



    scanf("%d", &a);

    printf("%d \n", ((a*3)+1)+((a*2)-1));



    return 0;

}
