#include <stdio.h>
#include <stdlib.h>

int main()
{

 double a, b;



    scanf("%lf", &a);
    b = a/3.6;
    printf("%lf \n", b);



    return 0;

}
