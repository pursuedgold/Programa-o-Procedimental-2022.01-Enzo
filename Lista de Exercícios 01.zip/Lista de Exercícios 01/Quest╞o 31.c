#include <stdio.h>
#include <stdlib.h>

int main()
{

 int a, b, c, d;



    scanf("%d", &a);

    printf("%d %d \n", a-1, a+1);



    return 0;

}
