#include <stdio.h>
#include <stdlib.h>

int main()
{

 double a, b=0;



    scanf("%lf", &a);
    b = a*1000;
    printf("%lf \n", b);



    return 0;

}
