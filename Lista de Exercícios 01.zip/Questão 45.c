#include <stdio.h>
#include <stdlib.h>

int main()
{


char a, b;
int c;


scanf("%c", &a);
c=a;
c+=32;
b=c;

printf("%c", b);






return 0;

}
