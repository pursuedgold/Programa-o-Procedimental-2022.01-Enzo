#include <stdio.h>
#include <stdlib.h>

int main()
{
    double  numero;

    scanf("%lf", &numero);
    printf("%lf\n", numero/5);






    return 0;


}
