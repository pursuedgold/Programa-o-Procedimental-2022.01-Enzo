#include <stdio.h>
#include <stdlib.h>

int main()
{

 double a, b, c, d;



    scanf("%lf %lf", &a, &b);

    printf("%lf \n", a*b);



    return 0;

}
