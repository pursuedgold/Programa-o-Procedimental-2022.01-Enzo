#include <stdio.h>
#include <stdlib.h>

int main()
{


double a = 780000;


    printf("Primeiro Ganhador: %lf \nSegundo Ganhador: %lf \nTerceiro Ganhador: %lf \n", a*0.46, a*0.32, a*0.22);








return 0;

}
