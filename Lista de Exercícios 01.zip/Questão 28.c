#include <stdio.h>
#include <stdlib.h>

int main()
{

 double a, b, c, d;



    scanf("%lf %lf %lf", &a, &b, &c);
    d = (a*a)+(b*b)+(c*c);
    printf("%lf \n", d);



    return 0;

}
